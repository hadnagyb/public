﻿using NUnit.Framework;
using Moq;
using System.Collections.Generic;
using System.Linq;
using R5TEPZ_HSZF_2024251.Model;
using R5TEPZ_HSZF_2024251.Persistence.MsSql;
using R5TEPZ_HSZF_2024251.Application;
using static R5TEPZ_HSZF_2024251.Persistence.MsSql.ShipmentDataProvider;
namespace R5TEPZ_HSZF_2024251.Test
{
    [TestFixture]
    public class ReportGeneratorTests
    {
        private Mock<IShipmentDataProvider> _mockDataProvider;
        private ReportGenerator _reportGenerator;

        [SetUp]
        public void SetUp()
        {
            _mockDataProvider = new Mock<IShipmentDataProvider>();
            _reportGenerator = new ReportGenerator(_mockDataProvider.Object);
        }

        [Test]
        public void GenerateShipReport_ShouldGenerateXml_WhenShipmentsExist()
        {
            // Arrange
            var imperialShipId = "12345";
            var shipments = new List<Shipment>
        {
            new Shipment
            {
                ImperialPermitNumber = imperialShipId,
                ShipmentDate = new System.DateTime(2024, 1, 1),
                Status = "completed",
                Cargo = new List<Cargo>
                {
                    new Cargo { CargoType = "Food", Quantity = 10, ImperialCredits = 100, Insurance = true, RiskLevel = "low" }
                }
            }
        };

            _mockDataProvider.Setup(dp => dp.GetShipmentsByImperialShipId(imperialShipId)).Returns(shipments);

            // Act
            Assert.DoesNotThrow(() => _reportGenerator.GenerateShipReport(imperialShipId));

            // Assert
            var expectedPath = $"Reports/{imperialShipId}/Report_{imperialShipId}_{System.DateTime.Now:yyyy-MM-dd}.xml";
            Assert.IsTrue(System.IO.File.Exists(expectedPath));
        }

        [Test]
        public void GenerateInsuredShipmentsReport_ShouldReturnReport_WhenInsuredShipmentsExist()
        {
            // Arrange
            var shipments = new List<Shipment>
        {
            new Shipment
            {
                ShipType = "Destroyer",
                ImperialPermitNumber = "12345",
                Cargo = new List<Cargo>
                {
                    new Cargo { ImperialCredits = 500, Insurance = true }
                }
            }
        };

            _mockDataProvider.Setup(dp => dp.GetInsuredShipments()).Returns(shipments);

            // Act
            var report = _reportGenerator.GenerateInsuredShipmentsReport();

            // Assert
            Assert.IsTrue(report.Contains("Biztosított szállítmányok:"));
            Assert.IsTrue(report.Contains("Destroyer"));
        }

        [Test]
        public void GenerateCaptainsShipments_ShouldReturnReport_WhenCaptainShipmentsExist()
        {
            // Arrange
            var captainReports = new List<ShipmentDataProvider.CaptainShipmentReport>
        {
            new ShipmentDataProvider.CaptainShipmentReport
            {
                Captain = "John Doe",
                Shipments = new List<ShipmentDataProvider.CaptainShipmentDetail>
                {
                    new ShipmentDataProvider.CaptainShipmentDetail
                    {
                        ShipType = "Cruiser",
                        ImperialPermitNumber = "56789",
                        TotalImperialCredits = 2000,
                        CargoCount = 3
                    }
                }
            }
        };

            _mockDataProvider.Setup(dp => dp.GetCaptainsShipments()).Returns(captainReports);

            // Act
            var report = _reportGenerator.GenerateCaptainsShipments();

            // Assert
            Assert.IsTrue(report.Contains("John Doe"));
            Assert.IsTrue(report.Contains("Cruiser"));
        }
        
        [Test]
        public void GenerateCargoUtilization_ShouldReturnCorrectFormattedReport()
        {
            // Arrange
            var mockCargoUtilization1 = new Mock<CargoUtilization>();
            mockCargoUtilization1.SetupGet(c => c.ShipType).Returns("Imperial Star Destroyer");
            mockCargoUtilization1.SetupGet(c => c.ShipmentDate).Returns(new DateTime(2024, 10, 1));
            mockCargoUtilization1.SetupGet(c => c.CargoCapacity).Returns(48000);
            mockCargoUtilization1.SetupGet(c => c.TotalCargoWeight).Returns(1000);
            mockCargoUtilization1.SetupGet(c => c.UtilizationPercentage).Returns(2);

            var mockCargoUtilization2 = new Mock<CargoUtilization>();
            mockCargoUtilization2.SetupGet(c => c.ShipType).Returns("Imperial Shuttle");
            mockCargoUtilization2.SetupGet(c => c.ShipmentDate).Returns(new DateTime(2024, 10, 3));
            mockCargoUtilization2.SetupGet(c => c.CargoCapacity).Returns(700);
            mockCargoUtilization2.SetupGet(c => c.TotalCargoWeight).Returns(100);
            mockCargoUtilization2.SetupGet(c => c.UtilizationPercentage).Returns(14);

            var mockUtilizationData = new List<CargoUtilization> { mockCargoUtilization1.Object, mockCargoUtilization2.Object };

            // Mock DataProvider Setup
            _mockDataProvider
                .Setup(dp => dp.GetShipmentsCapacity())
                .Returns(mockUtilizationData);

            string expectedReport =
                "Hajókapacitások kihasználtsága\n" +
                "Hajó típusa: Imperial Star Destroyer\n" +
                "Szállítás dátuma: 2024-10-01\n" +
                "Kapacitás: 48000 tons\n" +
                "Rakomány súlya: 1000 tons\n" +
                "Kihasználtság: 2%\n\n" +
                "Hajó típusa: Imperial Shuttle\n" +
                "Szállítás dátuma: 2024-10-03\n" +
                "Kapacitás: 700 tons\n" +
                "Rakomány súlya: 100 tons\n" +
                "Kihasználtság: 14%\n\n";

            // Act
            var result = _reportGenerator.GenerateCargoUtilization();

            // Assert
            Assert.AreEqual(expectedReport, result);
            _mockDataProvider.Verify(dp => dp.GetShipmentsCapacity(), Times.Once);
        }





    }
}

