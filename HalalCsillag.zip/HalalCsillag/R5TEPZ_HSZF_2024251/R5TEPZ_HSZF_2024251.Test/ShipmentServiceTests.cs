﻿using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using R5TEPZ_HSZF_2024251.Application;
using R5TEPZ_HSZF_2024251.Model;
using R5TEPZ_HSZF_2024251.Persistence.MsSql;

namespace R5TEPZ_HSZF_2024251.Test
{
    [TestFixture]
    public class ShipmentServiceTests
    {
        private Mock<IShipmentDataProvider> _mockDataProvider;
        private Mock<ReportGenerator> _mockReportGenerator;
        private ShipmentService _shipmentService;

        [SetUp]
        public void SetUp()
        {
            _mockDataProvider = new Mock<IShipmentDataProvider>();
            _mockReportGenerator = new Mock<ReportGenerator>(_mockDataProvider.Object);
            _shipmentService = new ShipmentService(_mockDataProvider.Object, _mockReportGenerator.Object);
        }

        [Test]
        public void AddShipment_ShouldCallDataProviderAddShipment()
        {
            // Arrange
            var shipment = new Shipment { Id = 1, ImperialPermitNumber = "12345" };

            // Act
            _shipmentService.AddShipment(shipment);

            // Assert
            _mockDataProvider.Verify(dp => dp.AddShipment(shipment), Times.Once);
        }

        [Test]
        public void AddCargoToShipment_ShouldCallDataProviderAddCargoToShipment()
        {
            // Arrange
            var cargo = new Cargo { Id = 1, CargoType = "Food" };

            // Act
            _shipmentService.AddCargoToShipment(1, cargo);

            // Assert
            _mockDataProvider.Verify(dp => dp.AddCargoToShipment(1, cargo), Times.Once);
        }

        [Test]
        public void GenerateShipReportXML_ShouldCallReportGeneratorGenerateShipReport()
        {
            // Arrange
            var imperialShipId = "12345";

            // Act
            _shipmentService.GenerateShipReportXML(imperialShipId);

            // Assert
            _mockReportGenerator.Verify(rg => rg.GenerateShipReport(imperialShipId), Times.Once);
        }


        [Test]
        public void SearchByCargoType_ShouldReturnCorrectReport_WhenDataExists()
        {
            // Arrange
            var searchType = "Weapons";
            var shipments = new List<Shipment>
        {
            new Shipment
            {
                Cargo = new List<Cargo>
                {
                    new Cargo { CargoType = "Weapons", Quantity = 5 }
                }
            }
        };

            _mockDataProvider.Setup(dp => dp.SearchByCargoType(searchType)).Returns(shipments);

            // Act
            var report = _shipmentService.SearchByCargoType(searchType);

            // Assert
            Assert.IsTrue(report.Contains("5"));
            Assert.IsTrue(report.Contains("Weapons"));
        }
        [Test]
        public void RemoveCargo_ShouldCallDataProvider()
        {
            // Arrange
            int shipmentId = 1;
            int cargoId = 10;

            // Act
            _shipmentService.RemoveCargo(shipmentId, cargoId);

            // Assert
            _mockDataProvider.Verify(dp => dp.RemoveCargo(shipmentId, cargoId), Times.Once);
        }


        [Test]
        public void UpdateShipment_ShouldCallUpdateShipment_WhenCalled()
        {
            // Arrange
            var shipment = new Shipment
            {
                Id = 1,
                ShipmentDate = DateTime.Now.AddDays(1),
                IsDelayed = false
            };

            // Act
            _shipmentService.UpdateShipment(shipment);

            // Assert
            // Ellenőrizzük, hogy a mockolt dataProvider.UpdateShipment metódus meghívódott a megfelelő paraméterekkel
            _mockDataProvider.Verify(dp => dp.UpdateShipment(It.Is<Shipment>(s => s.Id == shipment.Id)), Times.Once);
        }

        [Test]
        public void UpdateShipment_ShouldUpdateShipmentData_WhenCalled()
        {
            // Arrange
            var shipment = new Shipment
            {
                Id = 1,
                ShipmentDate = DateTime.Now.AddDays(1),
                IsDelayed = true
            };
            _mockDataProvider.Setup(dp => dp.UpdateShipment(It.IsAny<Shipment>()))
                                .Callback<Shipment>(updatedShipment =>
                                {
                                    // Ellenőrizzük, hogy a ShipmentDate frissült-e a kívánt értékre
                                    updatedShipment.IsDelayed = updatedShipment.ShipmentDate > DateTime.Now;
                                });
            // Act
            _shipmentService.UpdateShipment(shipment);

            // Assert

            Assert.IsTrue(shipment.IsDelayed, "The shipment should be marked as delayed.");
        }



    }
}

