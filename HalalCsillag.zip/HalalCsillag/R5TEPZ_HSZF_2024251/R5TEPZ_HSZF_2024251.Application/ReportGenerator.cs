﻿using R5TEPZ_HSZF_2024251.Persistence.MsSql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using R5TEPZ_HSZF_2024251.Model;


namespace R5TEPZ_HSZF_2024251.Application
{
    public class ReportGenerator
    {
        private readonly IShipmentDataProvider _shipmentDataProvider;

        public ReportGenerator(IShipmentDataProvider shipmentDataProvider)
        {
            _shipmentDataProvider = shipmentDataProvider;
        }

        public virtual void GenerateShipReport(string imperialShipId)
        {
            // Lekérjük az adott birodalmi hajóhoz tartozó szállítmányokat
            var shipments = _shipmentDataProvider.GetShipmentsByImperialShipId(imperialShipId);

            // Riport generálása XML formátumban
            var reportXml = new XElement("ShipReport",
                new XAttribute("ImperialShipId", imperialShipId),
                shipments.Select(shipment => new XElement("Shipment",
                    new XElement("Date", shipment.ShipmentDate.ToString("yyyy-MM-dd")),
                    new XElement("Status", shipment.Status),
                    new XElement("CargoCount", shipment.Cargo.Count),
                    new XElement("TotalImperialCredits", shipment.Cargo.Sum(c => c.ImperialCredits)),
                    new XElement("CargoItems", shipment.Cargo.Select(cargo => new XElement("Cargo",
                        new XElement("Type", cargo.CargoType),
                        new XElement("Quantity", cargo.Quantity),
                        new XElement("ImperialCredits", cargo.ImperialCredits),
                        new XElement("Insurance", cargo.Insurance),
                        new XElement("RiskLevel", cargo.RiskLevel)
                    )))
                ))
            );

            // Fájl mentése a hajó egyedi mappájába

            string shipFolder = Path.Combine("Reports", imperialShipId);
            Directory.CreateDirectory(shipFolder);

            string fileName = Path.Combine(shipFolder, $"Report_{imperialShipId}_{DateTime.Now:yyyy-MM-dd}.xml");
            reportXml.Save(fileName);
            
            
        }

        public string GenerateInsuredShipmentsReport()
        {
            string report = "Biztosított szállítmányok:\n";
            // Lekérjük a biztosított rakományokat és azok szállítmányait
            var insuredShipments = _shipmentDataProvider.GetInsuredShipments();

            foreach (var shipment in insuredShipments)
            {
                
                report += $"Hajó típusa: {shipment.ShipType}\n";
                report += $"Hajó azonosítója: {shipment.ImperialPermitNumber}\n";
                report += $"Teljes érték birodalmi kreditben: {shipment.Cargo.Sum(c => c.ImperialCredits)}\n";
                report += "Rakomány(ok):\n";
                foreach (var cargo in shipment.Cargo)
                {
                    report += $" - Type: {cargo.CargoType}\n";
                    report += $" - Imperial Credits: {cargo.ImperialCredits}\n";
                    report += $" - Quantity: {cargo.Quantity}\n";
                    report += $" - Risk Level: {cargo.RiskLevel}\n\n";
                }
            }
            return report;
        }

        public string GenerateCaptainsShipments()
        {
            string report = "Kapitányok szállítmányai\n";
            var captainShipments = _shipmentDataProvider.GetCaptainsShipments();
            

            foreach (var captainReport in captainShipments)
            {
                report += ($"Kapitány neve: {captainReport.Captain}\n");

                foreach (var shipment in captainReport.Shipments)
                {
                    report += ($"Hajó típusa: {shipment.ShipType}\n");
                    report += ($"Hajó azonosítója: {shipment.ImperialPermitNumber}\n");
                    report += ($"Teljes érték birodalmi kreditben: {shipment.TotalImperialCredits}\n");
                    report += ($"Rakományok száma: {shipment.CargoCount}\n\n");
                    
                }
            }
            return report;
        }

        public string GenerateCargoUtilization()
        {
            string report = "Hajókapacitások kihasználtsága\n";
            var shipUtilization = _shipmentDataProvider.GetShipmentsCapacity();

            foreach (var ship in shipUtilization)
            {
                report += ($"Hajó típusa: {ship.ShipType}\n");
                report += ($"Szállítás dátuma: {ship.ShipmentDate:yyyy-MM-dd}\n");
                report += ($"Kapacitás: {ship.CargoCapacity} tons\n");
                report += ($"Rakomány súlya: {ship.TotalCargoWeight} tons\n");
                report += ($"Kihasználtság: {ship.UtilizationPercentage}%\n\n");
                
            }
            return report;
        }


    }
   
}
