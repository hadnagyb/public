﻿using R5TEPZ_HSZF_2024251.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R5TEPZ_HSZF_2024251.Persistence.MsSql;
using R5TEPZ_HSZF_2024251.Application;

namespace R5TEPZ_HSZF_2024251.Application
{
   
    public interface IShipmentService
    {
        void AddShipment(Shipment shipment);// új szállítmányt 
        void AddCargoToShipment(int shipmentId, Cargo cargo);// és rakományt is
        
        void UpdateShipment(Shipment shipment);
        void UpdateCargo(Cargo cargo);
        void RemoveCargo(int shipmentId, int cargoId);//Adjon lehetőséget rakomány törlésére
        Shipment GetShipmentById(int id);
        Cargo GetCargoById(int id);
        void GenerateShipReportXML(string imperialShipId);
        string GenerateInsuredShipmentsReport();
        string GenerateCaptainsShipmentsReport();
        string GenerateCargoUtilizationReport();
        string SearchByCargoType(string searchCargoType);
        //
    }

    public class ShipmentService : IShipmentService
    {
        private readonly IShipmentDataProvider dataProvider;
        private readonly ReportGenerator reportGenerator;
        

        public ShipmentService(IShipmentDataProvider dataProvider, ReportGenerator reportGenerator)
        {
            this.dataProvider = dataProvider;
            this.reportGenerator = reportGenerator;
        }
        public void AddCargoToShipment(int shipmentId, Cargo cargo)
        {
            dataProvider.AddCargoToShipment(shipmentId, cargo);
        }

        public void AddShipment(Shipment shipment)
        {
            
            dataProvider.AddShipment(shipment);
        }

        public Shipment GetShipmentById(int id)
        {
            return dataProvider.GetShipmentById(id);
        }
        public Cargo GetCargoById(int id)
        {
            return dataProvider.GetCargoById(id);
        }
        

        public void RemoveCargo(int shipmentId, int cargoId)
        {
            dataProvider.RemoveCargo(shipmentId, cargoId);
        }

        public void UpdateShipment(Shipment shipment)
        {
            dataProvider.UpdateShipment(shipment);
            
        }
        public void UpdateCargo(Cargo cargo)
        {
            dataProvider.UpdateCargo(cargo);
            

        }
        public void GenerateShipReportXML(string imperialShipId)
        {
            reportGenerator.GenerateShipReport(imperialShipId);
        }
        public string GenerateInsuredShipmentsReport()
        {
            return reportGenerator.GenerateInsuredShipmentsReport();
        }
        
        public string GenerateCaptainsShipmentsReport()
        {
            return reportGenerator.GenerateCaptainsShipments();
        }

        public string GenerateCargoUtilizationReport()
        {
            return reportGenerator.GenerateCargoUtilization();
        }

        public string SearchByCargoType(string searchCargoType)
        {
            string report = "Találatok:\n";
            var search = dataProvider.SearchByCargoType(searchCargoType);
            
            if (search != null)
            {
                foreach (var ship in search)
                {
                    report += ($"Hajó típusa: {ship.ShipType}\n");
                    report += ($"Szállítás dátuma: {ship.ShipmentDate:yyyy-MM-dd}\n");
                    foreach (var cargo in ship.Cargo)
                    {
                        report += ($"Rakomány típusa: {cargo.CargoType}\n");
                        report += ($"Mennyiség: {cargo.Quantity}\n");
                    }
                    
                }
            }
            else
            {
                report += "A kerestt típus nem található";
            }

            return report;
        }

    }
}
