﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R5TEPZ_HSZF_2024251.Model
{
    public class Crew
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string CaptainName { get; set; }
        [Required]
        public int CrewCount { get; set; }

        public int ShipmentId { get; set; }
        public Shipment Shipment { get; set; }
    }
}
