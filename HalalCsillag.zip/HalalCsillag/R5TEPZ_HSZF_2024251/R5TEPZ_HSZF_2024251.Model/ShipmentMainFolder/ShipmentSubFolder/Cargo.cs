﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection.PortableExecutable;

namespace R5TEPZ_HSZF_2024251.Model
{
    public class Cargo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string CargoType { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public int ImperialCredits { get; set; }
        [Required]
        public bool Insurance { get; set; } 
        [Required]
        public string RiskLevel { get; set; }

        public int ShipmentId { get; set; }
        public Shipment Shipment{ get; set; }
    }
    
}
