﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace R5TEPZ_HSZF_2024251.Model
{
    public class Shipment
    {
        
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string ShipType { get; set; }
        [Required]
        public DateTime ShipmentDate { get; set; }
        [Required]
        public CargoCapacity CargoCapacity { get; set; } 
        [Required]
        public string Status { get; set; }
        [Required]
        public string ImperialPermitNumber { get; set; }
        
        public bool IsDelayed { get; set; }

        public Crew Crew { get; set; }

        public virtual ICollection<Cargo> Cargo{ get; set; }


        public Shipment()
        {
            Cargo = new HashSet<Cargo>();
        }



    }
    public class Root
    {
        public List<Shipment> Shipments { get; set; }
        public List<Cargo> Cargo { get; set; }
    }
}
