﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Identity.Client;
using R5TEPZ_HSZF_2024251.Application;
using R5TEPZ_HSZF_2024251.Model;
using R5TEPZ_HSZF_2024251.Persistence.MsSql;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using System.Text.Json;
using static System.Net.Mime.MediaTypeNames;

namespace R5TEPZ_HSZF_2024251.Presentation
{
    internal class Program
    {
        public static event EventHandler<string> AlertTheUser = (sender ,message) => Console.WriteLine(message);//értesít törléskor és ha késés van

        

        static void Main(string[] args)
        {
            
            Console.WriteLine("Loading database...");
            
            AppDbContext dbContext = new AppDbContext();

            ShipmentDataProvider shipmentDataProvider = new ShipmentDataProvider(dbContext);

            var host = Host.CreateDefaultBuilder()
                        .ConfigureServices((hostContext, services) =>
                        {
                            services.AddScoped<AppDbContext>();
                            services.AddSingleton<IShipmentDataProvider, ShipmentDataProvider>();
                            services.AddSingleton<IShipmentService, ShipmentService>();
                            services.AddSingleton<ReportGenerator>();
                        })
                        .Build();
            host.Start();

            //call ShipmentService
            using IServiceScope serviceScope = host.Services.CreateScope();
            var shipmentService = host.Services.GetRequiredService<IShipmentService>();

            //UI
            Console.Title = "Halálcsillag🌑";
            Console.Clear();
            Console.WriteLine("*****HalálCsillag*****");
            
            
            //Console.WriteLine("    .          __---__\r\n  .     .   .-'...:...'-.               .          .\r\n           / .  . : .__ .\\\r\n    .     /........./  \\ .\\  .   .                            .\r\n         / :  :   :| () | :\\                  .        .\r\n        :...........\\__/....:         .\r\n .      |___________________|              .                     .\r\n        |...................|               .\r\n  .     :  :  :   :   :   : :                          .\r\n      .  \\................./      .            .\r\n          \\  .  . : .  .  /   .                                .\r\n.      .   \\._........._./  .        .                   .\r\n              -..___..-                .         .\r\n");

            bool exit = false;
            while (!exit)
            {
            Console.WriteLine("    .          __---__\r\n  .     .   .-'...:...'-.               .          .\r\n           / .  . : .__ .\\\r\n    .     /........./  \\ .\\  .   .                            .\r\n         / :  :   :| () | :\\                  .        .\r\n        :...........\\__/....:         .\r\n .      |___________________|              .                     .\r\n        |...................|               .\r\n  .     :  :  :   :   :   : :                          .\r\n      .  \\................./      .            .\r\n          \\  .  . : .  .  /   .                                .\r\n.      .   \\._........._./  .        .                   .\r\n              -..___..-                .         .\r\n");

                Console.WriteLine("\nVálasszon egy műveletet:");
                Console.WriteLine("1 - Új szállítmány felvétele");
                Console.WriteLine("2 - Új rakomány felvétele egy meglévő szállítmányhoz");
                Console.WriteLine("3 - Szállítmányok szerkesztése");
                Console.WriteLine("4 - Rakomány szerkesztése");
                Console.WriteLine("5 - Rakomány törlése");
                Console.WriteLine("6 - Riportok készítése");
                Console.WriteLine("7 - Keresés rakomány típusa alapján");
                Console.WriteLine("0 - Kilépés");
                Console.Write("Választás: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    
                    case "1":
                        Console.Clear();
                        AddNewShipmentToDb();
                        Console.ReadLine();
                        Console.Clear();

                        break;
                    case "2":
                        Console.Clear();
                        AddNewCargoToDb();
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "3":
                        Console.Clear();
                        UpdateShipment();
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "4":
                        Console.Clear();
                        UpdateCargo();
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "5":
                        Console.Clear();
                        DeleteCargo();
                        
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "6":
                        Console.Clear();
                        
                        Report();
                        break;
                    case "7":
                        Console.Clear();
                        Search();
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Érvénytelen választás, próbálja újra!");
                        break;
                }
            }

            Console.WriteLine("Kilépés az alkalmazásból. Viszontlátásra!");

            void Search()
            {
                Console.WriteLine("Keresés: ");
                string searchFor = Console.ReadLine();
                Console.WriteLine(shipmentService.SearchByCargoType(searchFor));

            }

            void AddNewShipmentToDb()
            {
                Console.WriteLine("Új shipment hozzáadása");
                Shipment newShipment = new Shipment();

                    Console.Write("Hajó típusa: ");
                    newShipment.ShipType = Console.ReadLine();

                    Console.Write("Szállítás dátuma (YYYY-MM-DD): ");
                    newShipment.ShipmentDate = Convert.ToDateTime(Console.ReadLine());
                    if (newShipment.ShipmentDate < DateTime.Now)
                    {
                        //értesítés, feladat kérte
                        AlertTheUser.Invoke(null, "A hozzáadott szállítmány késik!");
                    }
                    newShipment.CargoCapacity = new CargoCapacity();
                    
                    newShipment.CargoCapacity.Unit = "tons";

                    Console.Write("Hajó kapacitása (tonna): ");
                    newShipment.CargoCapacity.Amount = int.Parse(Console.ReadLine());

                    Console.Write("Kézbesítés állapota: ");
                    newShipment.Status = Console.ReadLine();

                    Console.Write("Birodalmi azonosító: ");
                    newShipment.ImperialPermitNumber = Console.ReadLine();

                    newShipment.Crew = new Crew();
                    Console.Write("Kapitány neve: ");
                    newShipment.Crew.CaptainName = Console.ReadLine();

                    Console.Write("Legénység száma: ");
                    newShipment.Crew.CrewCount = int.Parse(Console.ReadLine());

                shipmentService.AddShipment(newShipment);
                Console.WriteLine("Szállítmány hozzáadva!");

            }

            void AddNewCargoToDb()
            {
                Console.WriteLine("Új rakomány felvétele");
                Cargo newCargo = new Cargo();

                Console.Write("A rakományhoz tartozó szállítmány azonosítója (shipment ID): ");
                int shipmentID = int.Parse(Console.ReadLine());

                Console.Write("Rakomány típusa: ");
                newCargo.CargoType = Console.ReadLine();

                Console.Write("Rakomány mennyisége (tonna): ");
                newCargo.Quantity = int.Parse(Console.ReadLine());

                Console.Write("Birodalmi kredit: ");
                newCargo.ImperialCredits = int.Parse(Console.ReadLine());

                Console.Write("Biztosított (true/false):");
                newCargo.Insurance = bool.Parse(Console.ReadLine());

                Console.Write("Kockázati szint: ");
                newCargo.RiskLevel = Console.ReadLine();

                shipmentService.AddCargoToShipment(shipmentID, newCargo);
                Console.WriteLine("Rakomány felvéve!");
            }

            void DeleteCargo()
            {
                Console.WriteLine("Rakomány törlése");
                Console.Write("Szállítmány azonosítója: ");
                int shipmentID = int.Parse(Console.ReadLine());

                Console.Write("Rakomány azonosítója: ");
                int cargoID = int.Parse(Console.ReadLine());

                shipmentService.RemoveCargo(shipmentID, cargoID);
                AlertTheUser.Invoke(null, $"A következő rakomány sikeresen törölve! Szállítmány:" +
                    $" {shipmentService.GetShipmentById(shipmentID).ShipType}, Rakománya: {shipmentService.GetCargoById(cargoID).CargoType}");

            }

            void UpdateShipment()
            {
                Console.WriteLine("Szállítmány szerkesztése");
                Shipment shipmentToUpdate = new Shipment();

                Console.Write("Melyik szállítmányt kell frissíteni (shipment id): ");
                int shipmentID = int.Parse(Console.ReadLine()); 
                shipmentToUpdate.Id = shipmentID;

                Console.Write("Hajó típusa: ");
                shipmentToUpdate.ShipType = Console.ReadLine();

                Console.Write("Szállítás dátuma (YYYY-MM-DD): ");
                shipmentToUpdate.ShipmentDate = Convert.ToDateTime(Console.ReadLine());

                shipmentToUpdate.CargoCapacity = new CargoCapacity();
                Console.Write("Hajó kapacitása (tonna): ");
                shipmentToUpdate.CargoCapacity.Unit = "tons";
                shipmentToUpdate.CargoCapacity.Amount = int.Parse(Console.ReadLine());

                Console.Write("Kézbesítés állapota: ");
                shipmentToUpdate.Status = Console.ReadLine();

                Console.Write("Birodalmi azonosító: ");
                shipmentToUpdate.ImperialPermitNumber = Console.ReadLine();

                shipmentToUpdate.Crew = new Crew();
                Console.Write("Kapitány neve: ");
                shipmentToUpdate.Crew.CaptainName = Console.ReadLine();

                Console.Write("Legénység száma: ");
                shipmentToUpdate.Crew.CrewCount = int.Parse(Console.ReadLine());

                shipmentService.UpdateShipment(shipmentToUpdate);
                
                Console.WriteLine("Szállítmány frissítve!");
            }

            void UpdateCargo()
            {
                Console.WriteLine("Rakomány szerkesztése");
                Cargo cargoToUpdate = new Cargo();

                Console.Write("Melyik szállítmányt kell frissíteni (id): ");
                int cargoID = int.Parse(Console.ReadLine());
                cargoToUpdate.Id = cargoID;

                Console.Write("A rakományhoz tartozó szállítmány azonosítója (shipment ID): ");
                cargoToUpdate.ShipmentId = int.Parse(Console.ReadLine());

                Console.Write("Rakomány típusa: ");
                cargoToUpdate.CargoType = Console.ReadLine();

                Console.Write("Rakomány mennyisége (tonna): ");
                cargoToUpdate.Quantity = int.Parse(Console.ReadLine());

                Console.Write("Birodalmi kredit: ");
                cargoToUpdate.ImperialCredits = int.Parse(Console.ReadLine());

                Console.Write("Biztosított (true/false): ");
                cargoToUpdate.Insurance = bool.Parse(Console.ReadLine());

                Console.Write("Kockázati szint: ");
                cargoToUpdate.RiskLevel = Console.ReadLine();

                shipmentService.UpdateCargo(cargoToUpdate);
                
                Console.WriteLine("Rakomány frissítve!");
            }

            void Report()
            {
                Console.Clear();
                
                bool exit = false;
                while (!exit)
                {
                    Console.WriteLine("Miről készüljön a riport:");
                    Console.WriteLine("1 - XML riport");
                    Console.WriteLine("2 - Biztosított szállítmányok");
                    Console.WriteLine("3 - Kapitányok szállítmányai");
                    Console.WriteLine("4 - Hajókapacitások kihasználtsága");
                    Console.WriteLine("0 - Vissza");
                    Console.Write("Választás: ");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.Clear();
                            Console.WriteLine("Melyik hajóról (imperialPermitId): ");
                            var imperialShipId = Console.ReadLine(); 
                            shipmentService.GenerateShipReportXML(imperialShipId);
                            Console.WriteLine("Riport elmentve!");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case "2":
                            
                            Console.WriteLine(shipmentService.GenerateInsuredShipmentsReport());
                            Console.ReadLine();
                            Console.Clear();

                            break;
                        case "3":
                            Console.WriteLine(shipmentService.GenerateCaptainsShipmentsReport());
                            Console.ReadLine();
                            Console.Clear();

                            break;
                        case "4":
                            Console.WriteLine(shipmentService.GenerateCargoUtilizationReport());
                            Console.ReadLine();
                            Console.Clear();

                            break;
                        case "0":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Érvénytelen választás, próbálja újra!");
                            break;
                    }
                }
                Console.Clear();

            }
        }
    }

    
}
