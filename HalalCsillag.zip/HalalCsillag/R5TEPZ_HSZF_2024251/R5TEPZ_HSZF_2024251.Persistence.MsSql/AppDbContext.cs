﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection.Emit;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using R5TEPZ_HSZF_2024251.Model;

namespace R5TEPZ_HSZF_2024251.Persistence.MsSql
{
    public class AppDbContext: DbContext
    {
        public DbSet<Shipment> Shipments { get; set; }
        public DbSet<Crew> Crews { get; set; }
        public DbSet<Cargo> Cargos { get; set; }
        public DbSet<CargoCapacity> CargoCapacities { get; set; }

        
        public AppDbContext() 
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
            
            
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           
            optionsBuilder.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DeathStardb;Integrated Security=True;MultipleActiveResultSets=true");
            
        }

        //seed database
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Shipment>()
                .HasOne(s => s.CargoCapacity)
                .WithOne(cc => cc.Shipment)
                .HasForeignKey<CargoCapacity>(cc => cc.ShipmentId);

            modelBuilder.Entity<Shipment>()
                .HasOne(s => s.Crew)
                .WithOne(c => c.Shipment)
                .HasForeignKey<Crew>(c => c.ShipmentId);

            modelBuilder.Entity<Shipment>()
                .HasMany(s => s.Cargo)
                .WithOne(c => c.Shipment)
                .HasForeignKey(c => c.ShipmentId);

        }

        
    }
}
