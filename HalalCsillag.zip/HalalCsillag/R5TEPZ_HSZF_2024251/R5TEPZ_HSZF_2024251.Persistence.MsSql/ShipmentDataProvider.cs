﻿using Microsoft.EntityFrameworkCore;
using R5TEPZ_HSZF_2024251.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static R5TEPZ_HSZF_2024251.Persistence.MsSql.ShipmentDataProvider;

//ADATOK LEKÉRÉSE
namespace R5TEPZ_HSZF_2024251.Persistence.MsSql
{
    public interface IShipmentDataProvider
    {
        
        void AddShipment(Shipment shipment);// új szállítmányt 
        void AddCargoToShipment(int shipmentId, Cargo cargo);// és rakományt is
       
        void UpdateShipment(Shipment shipment);
        void UpdateCargo(Cargo cargo);
        void RemoveCargo(int shipmentId, int cargoId);//Adjon lehetőséget rakomány törlésére
        Shipment GetShipmentById(int id);
        Cargo GetCargoById(int id);
        //linq és riport készítések
        IEnumerable<Shipment> GetShipmentsByImperialShipId(string imperialShipId);
        IEnumerable<Shipment> GetInsuredShipments();
        IEnumerable<CaptainShipmentReport> GetCaptainsShipments();
        IEnumerable<CargoUtilization> GetShipmentsCapacity();
        IEnumerable<Shipment> SearchByCargoType(string searchCargoType);
    }

    public class ShipmentDataProvider : IShipmentDataProvider
    {
        private readonly AppDbContext context;
        
        public ShipmentDataProvider(AppDbContext context)
        {
            this.context = context;
            LoadDB();
        }
        //shipment hozzáadása
        public void AddShipment(Shipment shipment)
        {
            if (shipment.ShipmentDate < DateTime.Now)
            {
                
                shipment.IsDelayed = true;
            }
            context.Shipments.Add(shipment);
            context.SaveChanges();
        }
        //cargo hozzáadása
        public virtual void AddCargoToShipment(int shipmentId, Cargo cargo)
        {
            var shipment = context.Shipments.Find(shipmentId);
            
            if (shipment != null)
            {
                shipment.Cargo.Add(cargo);
                context.SaveChanges();
                
                
            }
            else
            {
                throw new Exception("Nem található a szállítmány");
            }
        }
        
        //shipment update
        public void UpdateShipment(Shipment shipment)
        {
            var shipmentToUpdate = context.Shipments
                .Include(s => s.Cargo)
                .Include(s => s.Crew)
                .FirstOrDefault(s => s.Id == shipment.Id);
            shipmentToUpdate.ShipType = shipment.ShipType;
            shipmentToUpdate.ShipmentDate = shipment.ShipmentDate;
            shipmentToUpdate.Cargo = shipment.Cargo;
            
            shipmentToUpdate.Status = shipment.Status;
            shipmentToUpdate.ImperialPermitNumber = shipment.ImperialPermitNumber;
            shipmentToUpdate.Crew = shipment.Crew;
            
            context.Shipments.Update(shipmentToUpdate);
            context.SaveChanges();
            
        }
        //cargo update
        public void UpdateCargo(Cargo cargo)
        {
            var cargoToUpdate = context.Cargos
                .Include(s => s.Shipment)
                .FirstOrDefault(c => c.Id == cargo.Id);
            cargoToUpdate.ShipmentId = cargo.ShipmentId; 
            cargoToUpdate.CargoType = cargo.CargoType;
            cargoToUpdate.Quantity = cargo.Quantity;
            cargoToUpdate.ImperialCredits = cargo.ImperialCredits;
            cargoToUpdate.Insurance = cargo.Insurance;
            cargoToUpdate.RiskLevel = cargo.RiskLevel;

            context.Cargos.Update(cargoToUpdate);
            context.SaveChanges();
        }

        //cargo törlése teljseült shipmentből
        public void RemoveCargo(int shipmentId, int cargoId)
        {
            
            // Find the shipment and check if it's completed
            var shipment = context.Shipments
                .Include(s => s.Cargo)
                .FirstOrDefault(s => s.Id == shipmentId && s.Status == "completed");

            if (shipment == null)
            {
                throw new Exception("A szállítmány vagy nem található, vagy nem fejeződött be");
            }

            // Find the specific cargo to delete
            var cargo = shipment.Cargo.FirstOrDefault(c => c.Id == cargoId);
            if (cargo != null)
            {
                context.Cargos.Remove(cargo);
                context.SaveChanges();
            }
        }
        

        public Shipment GetShipmentById(int id)
        {
            return context.Shipments.FirstOrDefault(s => s.Id == id);
        }
        public Cargo GetCargoById(int id)
        {
            return context.Cargos.FirstOrDefault(c => c.Id == id);
        }

        public IEnumerable<Shipment> GetShipmentsByImperialShipId(string imperialShipId)
        {
            return context.Shipments
                       .Include(s => s.Cargo)
                       .Where(s => s.ImperialPermitNumber == imperialShipId)
                       .ToList();
        }
        public IEnumerable<Shipment> GetInsuredShipments()
        {
            return context.Shipments
                .Include(s => s.Cargo)
                .Where(s => s.Cargo.Any(c => c.Insurance==true))
                .ToList();
        }
        public IEnumerable<CaptainShipmentReport> GetCaptainsShipments()
        {
            var shipmentsByCaptain = context.Shipments
                .GroupBy(shipment => shipment.Crew.CaptainName)
                .Select(group => new CaptainShipmentReport
                {
                  Captain = group.Key,
                  Shipments = group.Select(shipment => new CaptainShipmentDetail
                  {
                      ImperialPermitNumber = shipment.ImperialPermitNumber,
                      ShipType = shipment.ShipType,
                      ShipmentDate = shipment.ShipmentDate,
                      CargoCount = shipment.Cargo.Count,
                      TotalImperialCredits = shipment.Cargo.Sum(c => c.ImperialCredits)
                  }).ToList()
                });

            return shipmentsByCaptain;
        }

        public IEnumerable<CargoUtilization> GetShipmentsCapacity()
        {
            var shipUtilization = context.Shipments
            .Select(shipment => new CargoUtilization
            {
                ShipType = shipment.ShipType,
                ShipmentDate = shipment.ShipmentDate,
                CargoCapacity = shipment.CargoCapacity.Amount,
                TotalCargoWeight = shipment.Cargo.Sum(c => c.Quantity),
                UtilizationPercentage = (double)Math.Round((double)shipment.Cargo.Sum(c => c.Quantity) / shipment.CargoCapacity.Amount * 100, 2)
            });
            return shipUtilization;
        }

        public IEnumerable<Shipment> SearchByCargoType(string searchCargoType)
        {
            var search = context.Shipments
                .Include(c => c.Cargo)
                .Where(s => s.Cargo.Any(c => c.CargoType == searchCargoType))
                .ToList();
            return search;
        }


        public Shipment GetShipment(int id)
        {
            throw new NotImplementedException();
        }

        //seed db gyak video alapján
        private void LoadDB()
        {
            var context = new AppDbContext();

           
            context.Database.EnsureCreated();

            string jsonFilePath = Path.Combine(Directory.GetCurrentDirectory(), "..", "..", "..", "..", "R5TEPZ_HSZF_2024251.Persistence.MsSql", "bin", "Debug", "net8.0", "shipmentdata.json");

            string jsonData = File.ReadAllText(jsonFilePath);

            // Deserialize JSON data to a list of Shipment objects
            var root = JsonSerializer.Deserialize<Root>(jsonData, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (root != null)
            {
                // Save each shipment to the database
                foreach (var shipment in root.Shipments)
                {
                    // Add the shipment to the context
                    context.Shipments.Add(shipment);

                }

                // Save changes to the database
                context.SaveChanges();
                
            }
            else
            {
                
                throw new Exception("Failed to deserialize JSON data.");
            }
        }

        public class CaptainShipmentReport
        {
            public string Captain { get; set; }
            public List<CaptainShipmentDetail> Shipments { get; set; }
        }

        public class CaptainShipmentDetail
        {
            public string ImperialPermitNumber { get; set; }
            public string ShipType { get; set; }
            public DateTime ShipmentDate { get; set; }
            public int CargoCount { get; set; }
            public int TotalImperialCredits { get; set; }
        }

        public class CargoUtilization
        {
            public virtual string ShipType { get; internal set; }
            public virtual DateTime ShipmentDate { get; internal set; }
            public virtual int CargoCapacity { get; internal set; }
            public virtual int TotalCargoWeight { get; internal set; }
            public virtual double UtilizationPercentage { get; internal set; }

           
        }
        


    }


}
